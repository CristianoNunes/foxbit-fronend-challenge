import { io } from 'socket.io-client';
const socket = io('wss://api.foxbit.com.br/');

export const socketInitializer = async () => {
  socket.on('connect', () => {
    console.log('connected');
  });
};

export const disconnectedtWebSocket = (ws: WebSocket) => {
  ws.addEventListener('close', function close() {
    console.log('disconnected');
  });
};

export const getInstruments = () => {
  const payloadInstruments = {
    m: 0,
    i: 2,
    n: 'GetInstruments',
    o: JSON.stringify({}),
  };
  socket.emit('connected', payloadInstruments);
};

export const subscribeLevel1 = (instrumentId: number) => {
  const payloadSubscribe = {
    m: 0,
    i: 2,
    n: 'SubscribeLevel1',
    o: JSON.stringify({ InstrumentId: instrumentId }),
  };
  socket.emit('connected', payloadSubscribe);
};

export const onMessage = (setData: (data) => void) => {
  socket.on('message', (response) => {
    const { n, o } = JSON.parse(response.data);
    const channel = n; // GetInstruments | SubscribeLevel1 | Level1UpdateEvent
    const data = JSON.parse(o);

    // RESPONSE WITH ALL CRYPTOS
    if (channel === 'GetInstruments') {
      setData(data);
      console.log(data);
    }

    // FIRST RESPONSE
    // if (channel === 'SubscribeLevel1') {
    //   setData(data);
    //   console.log(data);
    // }

    // UPDATES TO SUBSCRIBELEVEL1
    // if (channel === 'Level1UpdateEvent') {
    //   setData(data);
    //   console.log(data);
    // }
  });
};
