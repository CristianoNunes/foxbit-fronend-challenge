import { useEffect, useState } from 'react';
import Card from '../components/Card';
import ListCard from '../components/ListCards';
import Title from '../components/Title';

import { CardProps } from '../types';

export default function Home() {
  const [listCoins, setListCoins] = useState<CardProps[]>([]);
  useEffect(() => {
    const ws = new WebSocket('wss://api.foxbit.com.br/');

    ws.addEventListener('open', function open() {
      console.log('connected');

      // GET INSTRUMENTS
      const payloadInstruments = {
        m: 0,
        i: 2,
        n: 'GetInstruments',
        o: JSON.stringify({}),
      };

      ws.send(JSON.stringify(payloadInstruments));
    });

    ws.addEventListener('close', function close() {
      console.log('disconnected');
    });

    ws.addEventListener('message', function message(response) {
      const { n, o } = JSON.parse(response.data);
      const channel = n; // GetInstruments | SubscribeLevel1 | Level1UpdateEvent
      if (o === undefined) {
        return;
      }
      const data = JSON.parse(o);

      // RESPONSE WITH ALL CRYPTOS
      if (channel === 'GetInstruments') {
        setListCoins(data);
      }
    });
  }, []);

  return (
    <main>
      <Title>Foxbit - Frontend Challenge</Title>
      <ListCard>
        {listCoins.map((coin) => {
          return (
            <Card
              key={coin.InstrumentId}
              Product1Symbol={coin.Product1Symbol}
              Symbol={coin.Symbol}
              InstrumentId={coin.InstrumentId}
              SortIndex={coin.SortIndex}
            />
          );
        })}
      </ListCard>
    </main>
  );
}
