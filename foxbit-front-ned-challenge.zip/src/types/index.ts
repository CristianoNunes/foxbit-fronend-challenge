export interface CardProps {
  InstrumentId: number;
  Symbol: string;
  Product1Symbol: string;
  SortIndex: number;
}
