import { useEffect, useState } from 'react';

import { CardProps } from '../../types';

import {
  formatValueFourDecimals,
  formatValueTwoDecimals,
  changePointToComma,
  verifyPolarity,
} from '../../utils';

import up from '../../assets/up-arrow.svg';
import down from '../../assets/down-arrow.svg';

import * as S from './style';
import Image from 'next/image';
import CardLoading from '../CardLoading';

interface CoinType {
  OMSId?: number;
  InstrumentId?: number;
  LastTradedPx?: number;
  Rolling24HrVolume?: number;
  Rolling24HrPxChange?: number;
}

export default function Card({ InstrumentId, Product1Symbol }: CardProps) {
  const [firstCoin, setFirstCoin] = useState<CoinType>({});
  const [coin, setCoin] = useState<CoinType>({});

  useEffect(() => {
    const ws = new WebSocket('wss://api.foxbit.com.br/');

    ws.addEventListener('open', function open() {
      const payload = {
        m: 0,
        i: 2,
        n: 'SubscribeLevel1',
        o: JSON.stringify({ InstrumentId: InstrumentId }),
      };

      ws.send(JSON.stringify(payload));
    });

    ws.addEventListener('message', function message(response) {
      const { n, o } = JSON.parse(response.data);
      const channel = n; // GetIntruments | SubscribeLevel1 | Level1UpdateEvent
      if (o === undefined) {
        return;
      }
      const data = JSON.parse(o);

      // FIRST RESPONSE
      if (channel === 'SubscribeLevel1') {
        setFirstCoin(data);
      }

      // UPDATES TO SUBSCRIBELEVEL1
      if (channel === 'Level1UpdateEvent') {
        setCoin(data);
      }
    });
  }, []);

  const handleImgFallback = () => {
    if (Product1Symbol) {
      return (
        'https://statics.foxbit.com.br/icons/colored/' +
        Product1Symbol.toLowerCase() +
        '.svg'
      );
    }
    return './default-currency.svg';
  };

  return Object.keys(firstCoin).length === 0 &&
    Object.keys(coin).length === 0 ? (
    <CardLoading />
  ) : (
    <S.Wrapper>
      <S.Header>
        <S.Icon src={handleImgFallback()} />
        <S.PriceVariationChip
          $polarity={verifyPolarity(
            coin.Rolling24HrPxChange
              ? coin.Rolling24HrPxChange
              : firstCoin.Rolling24HrPxChange,
          )}
        >
          <S.PriceVariation>
            <Image
              src={
                verifyPolarity(
                  coin.Rolling24HrPxChange
                    ? coin.Rolling24HrPxChange
                    : firstCoin.Rolling24HrPxChange,
                )
                  ? up
                  : down
              }
              alt="seta direcional"
              width={10}
              height={10}
            />
            {coin.Rolling24HrPxChange
              ? changePointToComma(coin.Rolling24HrPxChange)
              : changePointToComma(firstCoin.Rolling24HrPxChange)}
            %
          </S.PriceVariation>
        </S.PriceVariationChip>
      </S.Header>
      <S.Name>{Product1Symbol}</S.Name>
      <S.WrapperPrice>
        <S.Coin>R$</S.Coin>
        <S.Price>
          {coin.LastTradedPx
            ? formatValueFourDecimals(coin.LastTradedPx)
            : formatValueFourDecimals(firstCoin.LastTradedPx)}
        </S.Price>
      </S.WrapperPrice>
      <S.WrapperVolume>
        <S.SpanVolume>Volume (24h):</S.SpanVolume>
        <S.Volume>
          {coin.Rolling24HrVolume
            ? formatValueTwoDecimals(coin.Rolling24HrVolume)
            : formatValueTwoDecimals(firstCoin.Rolling24HrVolume)}
          {' ' + Product1Symbol}
        </S.Volume>
      </S.WrapperVolume>
    </S.Wrapper>
  );
}
