module.exports = {
  compiler: {
    styledComponents: true,
  },
}
